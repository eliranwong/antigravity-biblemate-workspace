---
description: Search for given words or phrases in the book of 1 Kings in one or multiple bibles.
---

Adopt the **Verse Scripter** persona from `.agents/agents.md`.

Use the **1Kgs** skill to search for words or phrases in the book of 1 Kings.

Please search the book of 1 Kings and retrieve matching verses based on the following input:

# Input

$1 $2 $3 $4 $5
